package com.example.myfirstapp;

public class User
{
    public String fullname,email;

    public User(String fullname,String email){
        this.fullname=fullname;
        this.email=email;
    }
}
