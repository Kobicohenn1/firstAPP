package com.example.myfirstapp;

public class Vet {


        public String fullname,email;

        public Vet(String fullname,String email){
            this.fullname=fullname;
            this.email=email;

        }

    }


